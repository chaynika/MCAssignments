package com.healthmonitor.khann.healthmonitor;

import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.GridLabelRenderer;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;
import com.jjoe64.graphview.Viewport;

import java.io.File;
import java.util.Random;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.util.Log;

// TODO Assignment 2
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.content.Context;

// Wherever not marked as reference, is our code.
public class MainActivity extends AppCompatActivity implements OnClickListener {
    // Declare all the private variables for this class
    private LineGraphSeries mSeries1 = new LineGraphSeries<>();
    private LineGraphSeries mSeries2 = new LineGraphSeries<>();

    Random rand = new Random();
    int x_value = 0;
    Button runButton, stopButton;
    GraphView graphView;
    boolean firstRun = true;

    // TODO Assignment 2
    SQLiteDatabase db;
    EditText patientID;
    EditText Age;
    EditText patientName;
    String patientSex="Female";
    String patientIDText;
    String ageText;
    String patientNameText;
    private SensorManager sensorManager;
    Sensor accelerometer;
    // Reference to implement own Runnable class:
    // https://www.tutorialspoint.com/java/java_thread_control.htm
    class RunnableDemo implements Runnable {
        public Thread thread;
        public boolean suspended = false;

        public void run() {
            // we add 5000 new entries
            for (int i = 0; i < 5000; i++) {
                runOnUiThread(new RunnableDemo() {
                    @Override
                    public void run() {
                        addEntry();
                    }
                });

                // sleep to slow down the add of entries
                try {
                    Thread.sleep(500);
                    synchronized (this) {
                        while (suspended) {
                            wait();
                        }
                    }
                } catch (InterruptedException e) {
                    System.out.println("Exception caught: " + e);
                }
            }
        }

        void start () {
            if (thread == null) {
                thread = new Thread (this);
                thread.start ();
            }
        }

        void suspend() {
            suspended = true;
        }

        synchronized void resume() {
            suspended = false;
            notify();
        }
    }


    RunnableDemo R1 = new RunnableDemo();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // All initializations should go here
        // Created directory where database will be stored
        final File file = new File(Environment.getExternalStorageDirectory()+ File.separator+"Android/Data/CSE535_ASSIGNMENT2");
        if (!file.exists()) {
            file.mkdirs();
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        runButton = (Button) findViewById(R.id.run);
        runButton.setOnClickListener(this);
        stopButton = (Button) findViewById(R.id.stop);
        stopButton.setOnClickListener(this);
        graphView = (GraphView) findViewById(R.id.graph);
        Viewport viewport = graphView.getViewport();
        viewport.setYAxisBoundsManual(true);
        viewport.setMinY(0);
        viewport.setMaxY(2000);
        viewport.setScrollable(true);
        viewport.setBackgroundColor(-16777216);
        viewport.setDrawBorder(true);
        viewport.setXAxisBoundsManual(true);
        viewport.setMinX(0);
        viewport.setMaxX(40);
        viewport.setScalable(true);

        patientID = (EditText) findViewById(R.id.editText2);
        Age = (EditText) findViewById(R.id.editText5);
        patientName = (EditText) findViewById(R.id.editText);
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        // Save patientID to string
        patientID.setOnEditorActionListener(new TextView.OnEditorActionListener() {

            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                // TODO Auto-generated method stub
                patientIDText = patientID.getText().toString();
                return false;
            }
        });

        // Save age to string
        Age.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                // TODO Auto-generated method stub
                ageText = Age.getText().toString();
                return false;
            }
        });

        // Save patient name to string
        patientName.setOnEditorActionListener(new TextView.OnEditorActionListener() {

            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                patientNameText = patientName.getText().toString();
                return false;
            }
        });

        Button addtoDB = (Button) findViewById(R.id.addtodb);
        addtoDB.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    db = SQLiteDatabase.openDatabase(file.toString()+"/myDB", null, SQLiteDatabase.CREATE_IF_NECESSARY);
                    db.beginTransaction();
                    System.out.println("DEBUG: values " + patientIDText+" "+patientNameText+" "+ageText);
                    String table_name = patientNameText + "_" + patientIDText + "_" + ageText + "_" + patientSex;
                    try {
                        //perform your database operations here ...
                        db.execSQL("create table " + table_name + " ("
                                + " recID integer PRIMARY KEY autoincrement, "
                                + "timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP, "
                                + " x_values integer, "
                                + " y_values integer, "
                                + "z_values integer); ");

                        db.setTransactionSuccessful(); //commit your changes
                    } catch (SQLiteException e) {
                        //report problem
                    } finally {
                        db.endTransaction();
                    }
                } catch (SQLException e) {

                    Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void onRadioButtonClicked(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        switch (view.getId()) {
            case R.id.radioButton:
                if (checked) {
                    patientSex="Female";
                }
                break;
            case R.id.radioButton2:
                if (checked) {
                    patientSex="Male";
                }
                break;
        }
        System.out.println("patient sex is "+ patientSex);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.run: {
                // Triggered when run button is clicked
                Log.d("MR.bool", "Run was clicked ");
                // runButton.setEnabled(false);
                // stopButton.setEnabled(true);
                graphView.addSeries(mSeries1);
                if (firstRun) {
                    // Start graph for the first time if run clicked in the start
                    R1.start();
                } else {
                    // If run is clicked again, resume drawing graph from when it was stopped
                    R1.resume();
                }
                break;
            }
            case R.id.stop: {
                //Triggered when stop button is clicked
                Log.d("MR.bool", "Stop was clicked ");
                GraphView graph = (GraphView) findViewById(R.id.graph);
                graph.removeAllSeries();
                //runButton.setEnabled(true);
                // stopButton.setEnabled(false);
                firstRun = false;
                R1.suspend();
                break;
            }
        }
    }

    // Appends series objects to list after sleep in thread.
    // http://www.ssaurel.com/blog/create-a-real-time-line-graph-in-android-with-graphview/
    private void addEntry() {
        float y = rand.nextFloat() * (2000 - 20) + 20;
        mSeries1.appendData(new DataPoint(x_value, y), true, 500);
        x_value += 1;
    }
}